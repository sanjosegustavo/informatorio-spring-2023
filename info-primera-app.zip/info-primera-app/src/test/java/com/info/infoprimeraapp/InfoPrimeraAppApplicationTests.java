package com.info.infoprimeraapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoPrimeraAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
